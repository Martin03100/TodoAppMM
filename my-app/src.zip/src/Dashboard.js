import React, { useState, useEffect } from 'react';
import ShoppingList from './ShoppingList';

function Dashboard({ user, onLogout }) {
  const [lists, setLists] = useState([
    { name: 'Groceries', items: [], owner: user.username },
    { name: 'Work Tasks', items: [], owner: user.username }
  ]);
  const [selectedList, setSelectedList] = useState(null);

  const addList = () => {
    const newListName = prompt("Enter list name:");
    if (newListName) {
      setLists([...lists, { name: newListName, items: [], owner: user.username }]);
    }
  };

  const handleListClick = (list) => {
    setSelectedList(list);
  };

  const deleteList = () => {
    if (selectedList) {
      setLists(lists.filter((list) => list !== selectedList));
      setSelectedList(null); // Zatvorí zobrazený zoznam po vymazaní
    }
  };

  // Sledujeme zmeny v `lists` a obnovujeme `selectedList`
  useEffect(() => {
    if (selectedList) {
      const updatedList = lists.find((l) => l.name === selectedList.name);
      setSelectedList(updatedList);
    }
  }, [lists, selectedList]);

  return (
    <div className="dashboard">
      <h1>Welcome, {user.username}</h1>
      <button onClick={onLogout}>Logout</button>
      <button onClick={addList}>Add List</button>

      {/* Zobrazenie názvov zoznamov */}
      <div className="list-overview">
        {lists.map((list, index) => (
          <div key={index} className="list-name" onClick={() => handleListClick(list)}>
            {list.name}
          </div>
        ))}
      </div>

      {/* Zobrazenie vybraného zoznamu */}
      {selectedList && (
        <ShoppingList
          list={selectedList}
          setLists={setLists}
          lists={lists}
          user={user}
          onDelete={deleteList}
        />
      )}
    </div>
  );
}

export default Dashboard;


