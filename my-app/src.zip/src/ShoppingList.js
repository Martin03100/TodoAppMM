import React, { useState } from 'react';
import MembersModal from './MembersModal';

function ShoppingList({ list, setLists, lists, user, onDelete }) {
  const [newItem, setNewItem] = useState('');
  const [showMembers, setShowMembers] = useState(false);

  const addItem = () => {
    if (newItem) {
      const updatedList = {
        ...list,
        items: list.items ? [...list.items, { name: newItem, completed: false }] : [{ name: newItem, completed: false }]
      };
      setLists(lists.map((l) => (l.name === list.name ? updatedList : l)));
      setNewItem('');
    }
  };

  const toggleItemCompletion = (item) => {
    const updatedItems = list.items.map((i) =>
      i === item ? { ...i, completed: !i.completed } : i
    );
    const updatedList = { ...list, items: updatedItems };
    setLists(lists.map((l) => (l.name === list.name ? updatedList : l)));
  };

  return (
    <div className="shopping-list">
      <h2>{list.name}</h2>

      {user.username === list.owner && (
        <button className="delete-list" onClick={onDelete}>Delete List</button>
      )}

      {list.items && list.items.map((item, index) => (
        <div
          key={index}
          onClick={() => toggleItemCompletion(item)}
          className={item.completed ? 'completed' : ''}
        >
          {item.name}
        </div>
      ))}

      {/* Obalovací div pre vstupné pole */}
      <div className="input-container">
        <input
          type="text"
          placeholder="Add item"
          value={newItem}
          onChange={(e) => setNewItem(e.target.value)}
        />
      </div>
      <button className="add-item" onClick={addItem}>Add Item</button>

      <button className="members" onClick={() => setShowMembers(true)}>Members</button>
      {showMembers && (
        <>
          <div className="overlay" onClick={() => setShowMembers(false)}></div>
          <MembersModal list={list} setLists={setLists} setShowMembers={setShowMembers} />
        </>
      )}
    </div>
  );
}

export default ShoppingList;





