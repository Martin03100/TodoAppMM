import React, { useState } from 'react';
import './App.css';

function MembersModal({ list, setLists, setShowMembers }) {
  const [newMember, setNewMember] = useState('');

  const addMember = () => {
    if (newMember && !list.members?.includes(newMember)) {
      const updatedList = {
        ...list,
        members: list.members ? [...list.members, newMember] : [newMember],
      };
      setLists((prevLists) =>
        prevLists.map((l) => (l === list ? updatedList : l))
      );
      setNewMember('');
    }
  };

  const removeMember = (member) => {
    const updatedList = {
      ...list,
      members: list.members.filter((m) => m !== member),
    };
    setLists((prevLists) =>
      prevLists.map((l) => (l === list ? updatedList : l))
    );
  };

  return (
    <div className="modal">
      <h3>Members</h3>
      {list.members?.map((member, index) => (
        <div key={index} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>{member}</span>
          <button onClick={() => removeMember(member)}>✖</button>
        </div>
      ))}
      <input
        type="text"
        placeholder="Add member"
        value={newMember}
        onChange={(e) => setNewMember(e.target.value)}
      />
      <button className="add-member" onClick={addMember}>Add Member</button>
      <button className="close" onClick={() => setShowMembers(false)}>Close</button>
    </div>
  );
}

export default MembersModal;

